package com.corina.android.lab2_pam;

import android.os.Environment;

/**
 * Created by corina on 11/5/17.
 */
public class Constants {
    public final static String CALENDAR_EXTRA="Calendar";
    public final static String EVENT_SELECTED="Event Selected";
    public final static String ACTION_TYPE="ActionType";
    public final static String ACTION_TYPE_ADD="Add";
    public final static String ACTION_TYPE_EDIT="Edit";
    public final static String FILE_EXTRA="Extra File";
    public final static String EVENT_FOR_SHOW_ALARM="Event for Show Alarm";
}

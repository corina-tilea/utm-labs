package com.corina.android.lab3_1_pam;

/**
 * Created by corina on 20.12.2017.
 */
public class ErrorTracker {
    public final static String WRONG_URL_FORMAT="Error : URL Format is not valid";
    public final static String CONNECTION_ERROR="Error : Unable To Establish Connection";
    public final static String IO_EROR="Error : Unable To Read";
    public final static String RESPONSE_EROR="Error : Bad Response - ";
}